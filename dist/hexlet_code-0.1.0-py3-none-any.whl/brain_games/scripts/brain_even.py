#!/usr/bin/env python3
from brain_games.cli import welcome_user
import random
import prompt
COUNT_OF_ROUNDS = 3


def even():
    print('Answer "yes" if the number is even, otherwise answer "no".')
    i = 0
    while i < 3:
        number = random.randint(0, 50)
        print(f"Question: {number}")
        answer = prompt.string('Your answer: ')
        if answer == 'yes':
            answer = True
        elif answer == 'no':
            answer = False
        else:
            break


def main():
    welcome_user()


if __name__ == '__main__':
    main()
